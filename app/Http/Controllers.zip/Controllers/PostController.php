<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\User;
use App\Models\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PostController extends Controller
{
    public function index()
    {
        $category = null;
        if (request('category')) {
            $category = Category::firstWhere('slug', request('category'));
        }
        $posts = Post::with(["author", "category"])
            ->latest()
            ->filter(request(["search", 'category', 'author']))
            ->paginate(9)->withQueryString();
        
        $pengajuans = DB::table('Pengajuans')
            ->where('Pengajuans.ktp', '=', null)
            ->where('Pengajuans.sertifikat', '=', null)
            ->join('Users', 'Pengajuans.user_id', '=', 'Users.id')
            ->select('Pengajuans.*', 'Users.username as uname')
            ->get();

        $vendor_product = DB::table('posts')
            ->join('pengajuans', 'posts.user_id', '=', 'pengajuans.user_id')
            ->where('posts.user_id','pengajuans.user_id')
            ->get();
            
        return view('posts.posts', [
            "title" => "Marketplace",
            "category"  => $category,
            "pengajuans"  => $pengajuans,
            "vendor_product"  => $vendor_product,
            "posts" => $posts,
            'users' => User::query()->latest()->get()
        ]);
    }

    public function show(Post $post)
    {
        return view('posts.post', [
            "title" => "Marketplace",
            "post"  => $post
        ]);
    }
    
}
